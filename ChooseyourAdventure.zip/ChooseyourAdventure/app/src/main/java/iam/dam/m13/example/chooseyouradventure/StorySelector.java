package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class StorySelector extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_selector);
    }

    public void toLongStory(View v) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
        editor.putString("story", "long_test_story_");
        editor.commit();

        startActivity(new Intent(this, CharacterActivity.class));
        finish();
    }

    public  void toNormalWImgs(View v) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
        editor.putString("story", "test_story_");
        editor.commit();

        startActivity(new Intent(this, CharacterActivity.class));
        finish();
    }
}
