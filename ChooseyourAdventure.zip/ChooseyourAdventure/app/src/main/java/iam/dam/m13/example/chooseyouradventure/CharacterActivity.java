package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.IOException;

public class CharacterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character);
    }

    public void onHistory(View view){
        TextView tv= (TextView) findViewById(R.id.nameID);
        RadioGroup rg = (RadioGroup) findViewById(R.id.rGroup);

        String name = tv.getText().toString();
        int selectedId = rg.getCheckedRadioButtonId();

        if(name.equals("") || selectedId == -1){
            Toast.makeText(CharacterActivity.this,"Please complete all the fields, thank you :)",Toast.LENGTH_SHORT).show();
        } else {
            //Log.d("Name",name);
            RadioButton rb = (RadioButton) findViewById(selectedId);
            //Log.d("Gender", rb.getText().toString());
            String chInfo = name + "," + rb.getText();
            Log.d("INFO", chInfo);

            try {
                FileOutputStream fos = openFileOutput(MainMenu.CHARINFOFILE, MODE_PRIVATE);
                fos.write(chInfo.getBytes());
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Intent start = new Intent(this, Page.class);
            start.putExtra("page", 1);
            startActivity(start);
            this.finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,MainMenu.class);
                startActivity(Main);
                return true;
            case R.id.idGallery:
                Intent toGallery = new Intent(this, Gallery.class);
                startActivity(toGallery);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            case R.id.menuAboutUs:
                Intent toAboutUs = new Intent(this, AboutUs.class);
                startActivity(toAboutUs);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
