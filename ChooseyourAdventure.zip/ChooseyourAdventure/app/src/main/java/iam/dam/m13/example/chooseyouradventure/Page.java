package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class Page extends AppCompatActivity {

    //String with whole xml file
    //private String xmlFull;

    //Chapter page (on new game = 1, on resume get from save)
    private int pageNum;

    //private boolean gameEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page);

        //Gets sent page parameter
        pageNum = getIntent().getExtras().getInt("page");
        //gameEnd = getIntent().getExtras().getBoolean("end", false);
        Log.d("pageNumGotten", String.valueOf(pageNum));
        //Log.d("end", String.valueOf(gameEnd));

        //Loads XML
        /*try {
            xmlFull = getXML();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }*/

        //if (!gameEnd) {
            TextView tv = (TextView) findViewById(R.id.storyText);
            //tv.setText(xmlFull);
            try {
                tv.setText(getTextParser(pageNum));
                Log.d("control", "textview done");
                getOptions(pageNum);
            } catch (IOException | XmlPullParserException e) {
                e.printStackTrace();
            }
            //Log.d("pageNum", String.valueOf(pageNum));
        /*}
        else {

        }*/
    }

    private String getTextParser(int page) throws IOException, XmlPullParserException {
        Log.d("parserText", "start");
        Resources res = this.getResources();
        XmlResourceParser xpp = res.getXml(R.xml.story);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG) {
                Log.d("START_TAG", xpp.getName());
                if (xpp.getName().equals("page")) {
                    Log.d("equalsPage", xpp.getAttributeValue(null, "id"));
                    if (page == Integer.valueOf(xpp.getAttributeValue(null, "id"))){
                        xpp.next();
                        xpp.next();
                        String str = xpp.getText();
                        xpp.close();
                        Log.d("pageText", str);
                        return str;
                    }
                }
            }
            /*if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                xpp.next();
                xpp.next();
                return xpp.getText();
            }*/
            eventType = xpp.next();
        }
        xpp.close();
        return null;
    }

    private void getOptions(int page) throws IOException, XmlPullParserException {
        LinearLayout ll = (LinearLayout) findViewById(R.id.buttonLinearLayout);
        boolean done = false;
        Resources res = this.getResources();
        final XmlResourceParser xpp = res.getXml(R.xml.story);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                while (!done) {
                    if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("option")) {
                        final int toPage = Integer.valueOf(xpp.getAttributeValue(null, "toPage"));
                        Log.d("toPage", String.valueOf(toPage));
                        xpp.next();
                        Log.d("textOption", String.valueOf(xpp.getText()));
                        final Button option = new Button(this);
                        option.setText(xpp.getText());
                        option.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER);
                        option.setOnClickListener(new View.OnClickListener(){
                            @Override
                            public void onClick(View v) {
                                Log.d("onClickToPage", String.valueOf(toPage));
                                //pageNum = toPage;
                                xpp.close();
                                Intent nextPage;
                                if (toPage != 0) {
                                    nextPage = new Intent(Page.this, Page.class);
                                    nextPage.putExtra("page", toPage);
                                    startActivity(nextPage);
                                }
                                finish();
                            }
                        });
                        ll.addView(option);
                    }
                    else if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page < Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                        done = true;
                    }
                    eventType = xpp.next();
                }
            }
            eventType = xpp.next();
            if (done) {
                eventType = XmlPullParser.END_DOCUMENT;
            }
        }
        xpp.close();
    }

    /*private String getXML() throws IOException, XmlPullParserException {
        StringBuffer stringBuffer = new StringBuffer();
        Resources res = this.getResources();
        XmlResourceParser xpp = res.getXml(R.xml.story);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if(eventType == XmlPullParser.START_DOCUMENT) {
                stringBuffer.append("--- Start XML ---");
            }
            else if(eventType == XmlPullParser.START_TAG) {
                stringBuffer.append("\nSTART_TAG: "+xpp.getName());
            }
            else if(eventType == XmlPullParser.END_TAG) {
                stringBuffer.append("\nEND_TAG: "+xpp.getName());
            }
            else if(eventType == XmlPullParser.TEXT) {
                stringBuffer.append("\nTEXT: "+xpp.getText());
            }
            eventType = xpp.next();
        }
        stringBuffer.append("\n--- End XML ---");
        return stringBuffer.toString();
    }*/
}
