package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class Page extends AppCompatActivity {

    //Chapter page (on new game = 1, on resume get from save)
    private int pageNum;

    private String currentLang = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page);
    }

    @Override
    protected void onStart() {
        super.onStart();
        getPrefs();

        //Gets sent page parameter
        pageNum = getIntent().getExtras().getInt("page");
        //Log.d("pageNumGotten", String.valueOf(pageNum));

        // Gets the xml stroy file ID
        int storyID = getResources().getIdentifier("test_story_" + currentLang, "xml", getPackageName());

        TextView tv = (TextView) findViewById(R.id.storyText);
        try {
            tv.setText(getTextParser(pageNum, storyID));
            //Log.d("control", "textview done");
            getImage(pageNum, storyID);
            getOptions(pageNum, storyID);
        } catch (IOException | XmlPullParserException e) {
            e.printStackTrace();
        }
    }

    private void getPrefs() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        boolean lights = sharedPref.getBoolean("lights",false);

        currentLang = sharedPref.getString("listPrefs","en");
        //Log.d("Lang",currentLang);

        TextView txt = (TextView) findViewById(R.id.storyText);

        LinearLayout lPage = (LinearLayout) findViewById(R.id.activity_page);

        if(lights) {
            lPage.setBackgroundColor(Color.WHITE);
            txt.setTextColor(Color.BLACK);
        } else {
            lPage.setBackgroundColor(Color.BLACK);
            txt.setTextColor(Color.WHITE);
        }
    }

    private String getTextParser(int page, int storyID) throws IOException, XmlPullParserException {
        //Log.d("parserText", "start");
        Resources res = this.getResources();
        XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG) {
                //Log.d("START_TAG", xpp.getName());
                if (xpp.getName().equals("page")) {
                    //Log.d("equalsPage", xpp.getAttributeValue(null, "id"));
                    if (page == Integer.valueOf(xpp.getAttributeValue(null, "id"))){
                        xpp.next();
                        xpp.next();
                        String str = xpp.getText();
                        xpp.close();
                        //Log.d("pageText", str);
                        return str;
                    }
                }
            }
            eventType = xpp.next();
        }
        xpp.close();
        return null;
    }

    private void getImage(int page, int storyID) throws IOException, XmlPullParserException {
        boolean done = false;
        Resources res = this.getResources();
        final XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                while (!done) {
                    if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("img")) {
                        //Log.d("img", xpp.getAttributeValue(null, "src"));
                        int resID = getResources().getIdentifier(xpp.getAttributeValue(null, "src"), "drawable", getPackageName());
                        ImageView iv = (ImageView) findViewById(R.id.imageView);
                        iv.setImageResource(resID);
                    }
                    else if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page < Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                        done = true;
                    }
                    eventType = xpp.next();
                }
            }
            eventType = xpp.next();
            if (done) {
                eventType = XmlPullParser.END_DOCUMENT;
            }
        }
        xpp.close();
    }

    private void getOptions(int page, int storyID) throws IOException, XmlPullParserException {
        LinearLayout ll = (LinearLayout) findViewById(R.id.buttonLinearLayout);
        //Remove all view contents in case that is any a.k.a. changed language on settings
        ll.removeAllViewsInLayout();
        boolean done = false;
        Resources res = this.getResources();
        final XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                while (!done) {
                    if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("option")) {
                        final int toPage = Integer.valueOf(xpp.getAttributeValue(null, "toPage"));
                        //Log.d("toPage", String.valueOf(toPage));
                        xpp.next();
                        //Log.d("textOption", String.valueOf(xpp.getText()));
                        Button option = new Button(this);
                        option.setText(xpp.getText());
                        option.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER);
                        option.setOnClickListener(new View.OnClickListener(){
                            @Override
                            public void onClick(View v) {
                                //Log.d("onClickToPage", String.valueOf(toPage));
                                xpp.close();
                                Intent nextPage;
                                if (toPage != 0) {
                                    nextPage = new Intent(Page.this, Page.class);
                                    nextPage.putExtra("page", toPage);
                                    startActivity(nextPage);
                                }
                                finish();
                            }
                        });
                        ll.addView(option);
                    }
                    else if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page < Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                        done = true;
                    }
                    eventType = xpp.next();
                }
            }
            eventType = xpp.next();
            if (done) {
                eventType = XmlPullParser.END_DOCUMENT;
            }
        }
        xpp.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,MainMenu.class);
                startActivity(Main);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
