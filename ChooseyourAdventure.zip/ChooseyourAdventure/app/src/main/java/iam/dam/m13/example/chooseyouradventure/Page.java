package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Page extends AppCompatActivity {

    //Chapter page (on new game = 1, on resume get from save)
    private int pageNum;

    private String currentLang = "";
    private String currentStory = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page);

        //Gets sent page parameter
        pageNum = getIntent().getExtras().getInt("page");
        Log.d("pageNumGotten", String.valueOf(pageNum));
    }

    @Override
    protected void onStart() {
        super.onStart();
        getPrefs();

        // Gets the xml stroy file ID
        //int storyID = getResources().getIdentifier("test_story_" + currentLang, "xml", getPackageName());
        int storyID = getResources().getIdentifier(currentStory + currentLang, "xml", getPackageName());

        TextView tv = (TextView) findViewById(R.id.storyText);
        try {
            tv.setText(getTextParser(pageNum, storyID));
            //Log.d("control", "textview done");
            getImage(pageNum, storyID);
            getOptions(pageNum, storyID);
        } catch (IOException | XmlPullParserException e) {
            e.printStackTrace();
        }
    }

    private void getPrefs() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        boolean lights = sharedPref.getBoolean("lights",false);

        currentLang = sharedPref.getString("listPrefs","en");
        //Log.d("Lang",currentLang);

        currentStory = sharedPref.getString("story", "test_story_");

        TextView txt = (TextView) findViewById(R.id.storyText);

        LinearLayout lPage = (LinearLayout) findViewById(R.id.activity_page);

        if(lights) {
            lPage.setBackgroundColor(Color.WHITE);
            txt.setTextColor(Color.BLACK);
        } else {
            lPage.setBackgroundColor(Color.BLACK);
            txt.setTextColor(Color.WHITE);
        }
    }

    private String getTextParser(int page, int storyID) throws IOException, XmlPullParserException {
        //Log.d("parserText", "start");
        Resources res = this.getResources();
        XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        String str = "";
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG) {
                //Log.d("START_TAG", xpp.getName());
                if (xpp.getName().equals("page")) {
                    //Log.d("equalsPage", xpp.getAttributeValue(null, "id"));
                    if (page == Integer.valueOf(xpp.getAttributeValue(null, "id"))){
                        xpp.next();
                        xpp.next();
                        str += xpp.getText();
                        str = str.replaceAll("%charName%", getCharName());
                        str = str.replaceAll("%charGender%", getCharGender());
                        str = str.replaceAll("%charPronoun%", getCharPronoun());
                        xpp.close();
                        //Log.d("pageText", str);
                        return str;
                    }
                }
            }
            eventType = xpp.next();
        }
        xpp.close();
        return null;
    }

    private void getImage(int page, int storyID) throws IOException, XmlPullParserException {
        //Log.d("getImage: ", "start");
        boolean done = false;
        Resources res = this.getResources();
        final XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                while (!done) {
                    if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("img")) {
                        //Log.d("img", xpp.getAttributeValue(null, "src"));
                        int resID = getResources().getIdentifier(xpp.getAttributeValue(null, "src"), "drawable", getPackageName());

                        FileInputStream fis = openFileInput(MainMenu.IMGSUNLOCKEDFILE);
                        InputStreamReader isr = new InputStreamReader(fis);
                        BufferedReader br = new BufferedReader(isr);
                        String imagesLine = br.readLine();
                        fis.close();

                        boolean imgUnlocked = false;

                        if (imagesLine != null) {
                            Log.d("IMAGES", imagesLine);
                            String[] parts = imagesLine.split(",");

                            for (int i = 0; i < parts.length; i++) {
                                if (Integer.valueOf(parts[i]) == resID) {
                                    imgUnlocked = true;
                                    break;
                                }
                            }
                        }

                        if (!imgUnlocked) {
                            FileOutputStream fos = openFileOutput(MainMenu.IMGSUNLOCKEDFILE, MODE_PRIVATE);
                            if (imagesLine == null) {
                                fos.write(String.valueOf(resID).getBytes());
                            }
                            else {
                                fos.write((imagesLine + "," + resID).getBytes());
                            }
                            fos.close();
                        }

                        ImageView iv = (ImageView) findViewById(R.id.imageView);
                        iv.setImageResource(resID);
                    }
                    else if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page < Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                        done = true;
                    }
                    eventType = xpp.next();
                }
            }
            eventType = xpp.next();
            if (done) {
                eventType = XmlPullParser.END_DOCUMENT;
            }
        }
        xpp.close();
    }

    private void getOptions(int page, int storyID) throws IOException, XmlPullParserException {
        //Log.d("getOptions: ", "start");
        LinearLayout ll = (LinearLayout) findViewById(R.id.buttonLinearLayout);
        //Remove all view contents in case that is any a.k.a. changed language on settings
        ll.removeAllViewsInLayout();
        boolean done = false;
        Resources res = this.getResources();
        final XmlResourceParser xpp = res.getXml(storyID);
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page == Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                while (!done) {
                    if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("option")) {
                        final int toPage = Integer.valueOf(xpp.getAttributeValue(null, "toPage"));
                        //Log.d("toPage", String.valueOf(toPage));
                        xpp.next();
                        //Log.d("textOption", String.valueOf(xpp.getText()));
                        Button option = new Button(this);
                        option.setText(xpp.getText());
                        option.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER);
                        option.setOnClickListener(new View.OnClickListener(){
                            @Override
                            public void onClick(View v) {
                                try {
                                    FileInputStream fis = openFileInput(MainMenu.SAVEFILE);
                                    InputStreamReader isr = new InputStreamReader(fis);
                                    BufferedReader br = new BufferedReader(isr);
                                    String savedLine = br.readLine();
                                    //Log.d("SAVED", savedLine);
                                    fis.close();

                                    FileOutputStream fos = openFileOutput(MainMenu.SAVEFILE, MODE_PRIVATE);
                                    fos.write((savedLine + "," + toPage).getBytes());
                                    fos.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                //Log.d("onClickToPage", String.valueOf(toPage));
                                xpp.close();
                                Intent nextPage;
                                if (toPage != 0) {
                                    if (toPage == 1) {
                                        try{
                                            FileOutputStream fos = openFileOutput(MainMenu.SAVEFILE, MODE_PRIVATE);
                                            fos.write(String.valueOf(toPage).getBytes());
                                            fos.close();
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    nextPage = new Intent(Page.this, Page.class);
                                    nextPage.putExtra("page", toPage);
                                    startActivity(nextPage);
                                }
                                else if (toPage == 0) {
                                    deleteFile(MainMenu.SAVEFILE);
                                }
                                finish();
                            }
                        });
                        ll.addView(option);
                    }
                    else if (eventType == XmlPullParser.START_TAG && xpp.getName().equals("page") && page < Integer.valueOf(xpp.getAttributeValue(null, "id"))) {
                        done = true;
                    }
                    eventType = xpp.next();
                }
            }
            eventType = xpp.next();
            if (done) {
                eventType = XmlPullParser.END_DOCUMENT;
            }
        }
        xpp.close();
    }

    private String getCharName() {
        String name = "NONAME";
        try {
            FileInputStream fis = openFileInput(MainMenu.CHARINFOFILE);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String info = br.readLine();
            String[] parts = info.split(",");
            name = parts[0];
        } catch (IOException e) {
            e.printStackTrace();
        }
        return name;
    }

    private String getCharGender() {
        String gender = "NOGENDER";
        try {
            FileInputStream fis = openFileInput(MainMenu.CHARINFOFILE);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String info = br.readLine();
            String[] parts = info.split(",");
            gender = parts[1];
        } catch (IOException e) {
            e.printStackTrace();
        }
        return gender;
    }

    private String getCharPronoun() {
        String pronoum = "NOPRONOUM";
        switch (getCharGender()) {
            case "Male":
                pronoum = "his";
                break;
            case "Female":
                pronoum = "her";
                break;
        }
        return pronoum;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,MainMenu.class);
                startActivity(Main);
                return true;
            case R.id.idGallery:
                Intent toGallery = new Intent(this, Gallery.class);
                startActivity(toGallery);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            case R.id.menuAboutUs:
                Intent toAboutUs = new Intent(this, AboutUs.class);
                startActivity(toAboutUs);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
