package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;

import java.io.File;

public class Gallery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        GridView gridView = (GridView) findViewById(R.id.gridView);
        File imgsFile = getBaseContext().getFileStreamPath(MainMenu.IMGSUNLOCKEDFILE);
        gridView.setAdapter(new ImageAdapter(this, imgsFile));

        //gridView.setOnI
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,MainMenu.class);
                startActivity(Main);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            case R.id.menuAboutUs:
                Intent toAboutUs = new Intent(this, AboutUs.class);
                startActivity(toAboutUs);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onRestart() {
        finish();
        super.onRestart();
    }
}
