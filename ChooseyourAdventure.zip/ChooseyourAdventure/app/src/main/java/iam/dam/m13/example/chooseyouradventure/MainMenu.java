package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    //New Game button, loads new Game
    public void newGame(View v) {
        Intent toNewGame = new Intent(this,Page.class);
        toNewGame.putExtra("page", 1); //Sends "page" as parameter
        Log.d("Start", "new game");
        startActivity(toNewGame);
    }
}
