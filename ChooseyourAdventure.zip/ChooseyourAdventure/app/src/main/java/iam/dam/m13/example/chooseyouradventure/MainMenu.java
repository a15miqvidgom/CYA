package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainMenu extends AppCompatActivity {

    protected static final String SAVEFILE = "save";
    protected static final String IMGSUNLOCKEDFILE = "imagesUnlocked";
    protected static final String CHARINFOFILE = "character";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
    }

    @Override
    protected void onStart() {
        super.onStart();
        File imgsFile = getBaseContext().getFileStreamPath(IMGSUNLOCKEDFILE);
        //imgsFile.delete();
        if (!imgsFile.exists()) {
            try {
                FileOutputStream fos = openFileOutput(IMGSUNLOCKEDFILE, MODE_PRIVATE);
                fos.write("".getBytes());
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //New Game button, loads new Game
    public void newGame(View v) {
        try {
            FileOutputStream fos = openFileOutput(SAVEFILE, MODE_PRIVATE);
            fos.write("1".getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*Intent toNewGame = new Intent(this,Page.class);
        toNewGame.putExtra("page", 1); //Sends "page" as parameter
        //Log.d("Start", "new game");
        startActivity(toNewGame);*/
        //startActivity(new Intent(this, CharacterActivity.class));
        startActivity(new Intent(this, StorySelector.class));

    }

    public void resume(View v) {
        try {
            FileInputStream fis = openFileInput(SAVEFILE);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String savedLine = br.readLine();
            fis.close();
            Log.d("SAVE", savedLine);
            String[] parts = savedLine.split(",");
            Log.d("LAST SAVE", parts[parts.length - 1]);
            Intent toResume = new Intent(this,Page.class);
            toResume.putExtra("page", Integer.valueOf(parts[parts.length - 1]));
            startActivity(toResume);
        } catch (IOException e) {
            //e.printStackTrace();
            Toast.makeText(this, getString(R.string.noSaveData), Toast.LENGTH_SHORT).show();
        }
    }

    public void toGallery(View v) {
        Intent toGallery = new Intent(this, Gallery.class);
        startActivity(toGallery);
    }

    public void toPreferences(View v) {
        Intent Prefs = new Intent(this, Preferences.class);
        startActivity(Prefs);
    }

    public void exitButton(View v) {
        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
        homeIntent.addCategory( Intent.CATEGORY_HOME );
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(homeIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.idGallery:
                Intent toGallery = new Intent(this, Gallery.class);
                startActivity(toGallery);
                return true;
            case R.id.pPrefs:
                Intent toPrefs = new Intent(this, Preferences.class);
                startActivity(toPrefs);
                return true;
            case R.id.menuAboutUs:
                Intent toAboutUs = new Intent(this, AboutUs.class);
                startActivity(toAboutUs);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
