package iam.dam.m13.example.chooseyouradventure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class AboutUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,MainMenu.class);
                startActivity(Main);
                return true;
            case R.id.idGallery:
                Intent toGallery = new Intent(this, Gallery.class);
                startActivity(toGallery);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onRestart() {
        finish();
        super.onRestart();
    }
}
