package com.example.ausias.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.ListPreference;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        boolean lights = sharedPref.getBoolean("lights",false);

        String langPref = sharedPref.getString("listPrefs","en");
        



        Log.d("Lang",langPref);
        TextView txt = (TextView) findViewById(R.id.textID);

        //LinearLayout lMainMenu = (LinearLayout) findViewById(R.id.activity_main_menu);
        //LinearLayout lPage = (LinearLayout) findViewById(R.id.activity_page);

        RelativeLayout lMain = (RelativeLayout) findViewById(R.id.activity_main);

        if(lights) {
            // lMainMenu.setBackgroundColor(Color.WHITE);
            // lPage.setBackgroundColor(Color.WHITE);
            lMain.setBackgroundColor(Color.WHITE);
            txt.setTextColor(Color.BLACK);
        } else {
            // lMainMenu.setBackgroundColor(Color.BLACK);
            // lPage.setBackgroundColor(Color.BLACK);
            lMain.setBackgroundColor(Color.BLACK);
            txt.setTextColor(Color.WHITE);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.mainMenu:
                Intent Main = new Intent(this,Main.class);
                startActivity(Main);
                return true;
            case R.id.pPrefs:
                Intent Prefs = new Intent(this,Preferences.class);
                startActivity(Prefs);
                return true;
            case R.id.idGallery:
                Intent Gallery = new Intent(this,Gallery.class);
                startActivity(Gallery);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
